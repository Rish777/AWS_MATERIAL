import json

def lambda_handler(event, context):
    print (json.dumps(event.get('who')))
    # TODO implement
    return str("Hello," + event.get('who') + "!")
    


