import sys
from pyspark.sql.functions import *
from pyspark.sql.types import *

from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from awsglue.dynamicframe import DynamicFrame
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

## @params: [JOB_NAME]
args = getResolvedOptions(sys.argv, ['JOB_NAME'])

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

## @type: DataSource
## @args: [database = "training", table_name = "population", transformation_ctx = "datasource0"]
## @return: datasource0
## @inputs: []
datasource0 = glueContext.create_dynamic_frame.from_catalog(database = "training", table_name = "population", transformation_ctx = "datasource0")

## @type: DataSource
## @args: [database = "training", table_name = "zip", transformation_ctx = "datasource1"]
## @return: datasource1
## @inputs: []
datasource1 = glueContext.create_dynamic_frame.from_catalog(database = "training", table_name = "zip", transformation_ctx = "datasource1")

## @type: ApplyMapping
## @args: [mapping = [("province_state", "string", "province_state", "string"), ("country_region", "string", "country_region", "string"), ("lat", "string", "lat", "string"), ("long_", "string", "long_", "string"), ("population", "string", "population", "string")], transformation_ctx = "applymapping1"]
## @return: applymapping1
## @inputs: [frame = datasource0]
applymapping1 = ApplyMapping.apply(frame = datasource0, mappings = [("province_state", "string", "province_state", "string"), ("country_region", "string", "country_region", "string"), ("lat", "string", "lat", "string"), ("long_", "string", "long_", "string"), ("population", "string", "population", "string")], transformation_ctx = "applymapping1")

## @type: ApplyMapping
## @args: [mapping = [("zip_code", "integer", "zip_code", "integer"), ("county", "string", "county", "string")], transformation_ctx = "applymapping2"]
## @return: applymapping2
## @inputs: [frame = datasource1]
applymapping2 = ApplyMapping.apply(frame = datasource1, mappings = [("zip_code", "integer", "zip_code", "integer"), ("county", "string", "county", "string")], transformation_ctx = "applymapping2")

## @type: Filter
## @args: [f = filter_function, transformation_ctx = "filter1"]
## @return: filter1
## @inputs: [frame = applymapping1]
def filter_function(x):
	if x["country_region"] in ["US"] and len(x["province_state"]) > 0:
	    return x
filter1 = Filter.apply(frame = applymapping1, f = filter_function, transformation_ctx = "filter1")

## @type: DropFields
## @args: [paths = ["lat", "long_"], transformation_ctx = "dropfields1"]
## @return: dropfields1
## @inputs: [frame = filter1]
dropfields1 = DropFields.apply(frame = filter1, paths = ["lat", "long_"], transformation_ctx = "dropfields1")

## @type: CustomTransformation
## @args: [transformation_ctx = "custotTransformation1"]
## @return: dynm_
## @inputs: [frame = dropfields1]
data_ = dropfields1.toDF().select(["province_state", col("population").cast(IntegerType())]).groupby(["province_state"]).agg(sum("population").cast(IntegerType()).alias("population")).repartition(1)
dynm_ = DynamicFrame.fromDF(data_, glueContext, "dynm_")

## @type: Map
## @args: [f = map_function, transformation_ctx = "map1"]
## @return: map1
## @inputs: [frame = dynm_]
def map_function(dynamicRecord):
    dynamicRecord['province_state'] = dynamicRecord['province_state'].upper()
    dynamicRecord['population'] = dynamicRecord['population']
    return dynamicRecord
map1 = Map.apply(frame = dynm_, f = map_function, transformation_ctx = "map1")

## @type: CustomTransformation
## @args: [transformation_ctx = "custotTransformation2"]
## @return: dynm_1
## @inputs: [frame = applymapping2]
data_ = applymapping2.toDF().groupby(["county"]).agg(collect_set("zip_code").alias("zip")).repartition(1)
dynm_1 = DynamicFrame.fromDF(data_, glueContext, "dynm_1")

## @type: Join
## @args: [keys1 = ['province_state'], keys2 = ['county']]
## @return: join1
## @inputs: [frame1 = map1, frame2 = dynm_1]
join1 = Join.apply(frame1 = map1, frame2 = dynm_1, keys1 = ['province_state'], keys2 = ['county'], transformation_ctx = "join1")

## @type: DataSink
## @args: [connection_type = "s3", connection_options = {"path": "s3://antm-034263553825-training/us_data/result"}, format = "json", transformation_ctx = "datasink2"]
## @return: datasink2
## @inputs: [frame = join1]
data_ = join1.toDF().repartition(1)
join1_1 = DynamicFrame.fromDF(data_, glueContext, "join1_1")
datasink2 = glueContext.write_dynamic_frame.from_options(frame = join1_1, connection_type = "s3", connection_options = {"path": "s3://antm-034263553825-training/us_data/result"}, format = "json", transformation_ctx = "datasink2")

job.commit()
