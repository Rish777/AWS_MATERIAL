import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import re
from awsglue.dynamicframe import DynamicFrameCollection
from awsglue.dynamicframe import DynamicFrame

def MyTransform1(glueContext, dfc) -> DynamicFrameCollection:
    selected = dfc.select(list(dfc.keys())[0]).toDF()
    selected.createOrReplaceTempView("data")
    totals = spark.sql("select upper(province_state) as province_state, sum(population) as population from data group by upper(province_state)")
    results = DynamicFrame.fromDF(totals, glueContext, "results")
    return DynamicFrameCollection({"results": results}, glueContext)
def MyTransform2(glueContext, dfc) -> DynamicFrameCollection:
    selected = dfc.select(list(dfc.keys())[0]).toDF()
    selected.createOrReplaceTempView("data")
    totals = spark.sql("select collect_set(zip_code) as zip_code, county from data group by county")
    results = DynamicFrame.fromDF(totals, glueContext, "results")
    return DynamicFrameCollection({"results": results}, glueContext)

## @params: [JOB_NAME]
args = getResolvedOptions(sys.argv, ['JOB_NAME'])

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)
## @type: DataSource
## @args: [database = "training", table_name = "population", transformation_ctx = "DataSource0"]
## @return: DataSource0
## @inputs: []
DataSource0 = glueContext.create_dynamic_frame.from_catalog(database = "training", table_name = "population", transformation_ctx = "DataSource0")
## @type: ApplyMapping
## @args: [mappings = [("province_state", "string", "province_state", "string"), ("country_region", "string", "country_region", "string"), ("population", "string", "population", "int")], transformation_ctx = "Transform1"]
## @return: Transform1
## @inputs: [frame = DataSource0]
Transform1 = ApplyMapping.apply(frame = DataSource0, mappings = [("province_state", "string", "province_state", "string"), ("country_region", "string", "country_region", "string"), ("population", "string", "population", "int")], transformation_ctx = "Transform1")
## @type: Filter
## @args: [f = lambda row : (bool(re.match("US", row["country_region"])) and bool(re.match("(.|\s)*\S(.|\s)*", row["province_state"]))), transformation_ctx = "Transform4"]
## @return: Transform4
## @inputs: [frame = Transform1]
Transform4 = Filter.apply(frame = Transform1, f = lambda row : (bool(re.match("US", row["country_region"])) and bool(re.match("(.|\s)*\S(.|\s)*", row["province_state"]))), transformation_ctx = "Transform4")
## @type: CustomCode
## @args: [dynamicFrameConstruction = DynamicFrameCollection({"Transform4": Transform4}, glueContext), className = MyTransform1, transformation_ctx = "Transform2"]
## @return: Transform2
## @inputs: [dfc = Transform4]
Transform2 = MyTransform1(glueContext, DynamicFrameCollection({"Transform4": Transform4}, glueContext))
## @type: SelectFromCollection
## @args: [key = list(Transform2.keys())[0], transformation_ctx = "Transform0"]
## @return: Transform0
## @inputs: [dfc = Transform2]
Transform0 = SelectFromCollection.apply(dfc = Transform2, key = list(Transform2.keys())[0], transformation_ctx = "Transform0")
## @type: DataSource
## @args: [database = "training", table_name = "zip", transformation_ctx = "DataSource1"]
## @return: DataSource1
## @inputs: []
DataSource1 = glueContext.create_dynamic_frame.from_catalog(database = "training", table_name = "zip", transformation_ctx = "DataSource1")
## @type: ApplyMapping
## @args: [mappings = [("zip_code", "int", "zip_code", "int"), ("county", "string", "county", "string")], transformation_ctx = "Transform3"]
## @return: Transform3
## @inputs: [frame = DataSource1]
Transform3 = ApplyMapping.apply(frame = DataSource1, mappings = [("zip_code", "int", "zip_code", "int"), ("county", "string", "county", "string")], transformation_ctx = "Transform3")
## @type: CustomCode
## @args: [dynamicFrameConstruction = DynamicFrameCollection({"Transform3": Transform3}, glueContext), className = MyTransform2, transformation_ctx = "Transform5"]
## @return: Transform5
## @inputs: [dfc = Transform3]
Transform5 = MyTransform2(glueContext, DynamicFrameCollection({"Transform3": Transform3}, glueContext))
## @type: SelectFromCollection
## @args: [key = list(Transform5.keys())[0], transformation_ctx = "Transform7"]
## @return: Transform7
## @inputs: [dfc = Transform5]
Transform7 = SelectFromCollection.apply(dfc = Transform5, key = list(Transform5.keys())[0], transformation_ctx = "Transform7")
## @type: Join
## @args: [columnConditions = ["="], joinType = left, keys2 = ["county"], keys1 = ["province_state"], transformation_ctx = "Transform6"]
## @return: Transform6
## @inputs: [frame1 = Transform0, frame2 = Transform7]
Transform0DF = Transform0.toDF()
Transform7DF = Transform7.toDF()
Transform6 = DynamicFrame.fromDF(Transform0DF.join(Transform7DF, (Transform0DF['province_state'] == Transform7DF['county']), "left"), glueContext, "Transform6")
## @type: DataSink
## @args: [connection_type = "s3", format = "json", connection_options = {"path": "s3://antm-034263553825-training/us_data/result-studio/", "partitionKeys": ["province_state"]}, transformation_ctx = "DataSink0"]
## @return: DataSink0
## @inputs: [frame = Transform6]
DataSink0 = glueContext.write_dynamic_frame.from_options(frame = Transform6, connection_type = "s3", format = "json", connection_options = {"path": "s3://antm-034263553825-training/us_data/result-studio/", "partitionKeys": ["province_state"]}, transformation_ctx = "DataSink0")
job.commit()