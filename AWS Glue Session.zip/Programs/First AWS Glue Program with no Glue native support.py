from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import configparser
import sys
from awsglue.utils import getResolvedOptions

args_ = getResolvedOptions(sys.argv, ['JOB_NAME'])

cnfg_ = configparser.ConfigParser()
cnfg_.read('training.ini')
sprk_ = SparkSession.builder.appName(args_['JOB_NAME']).getOrCreate()

qury_ = "SELECT country, sum(confirmed), sum(recovered), sum(deaths) FROM " \
        "(SELECT country_col_ country, confirmed_col_ confirmed, recovered_col_ recovered, deaths_col_ deaths " \
        "FROM %s.%s " \
        "LATERAL VIEW explode(data['Country']) country_ AS country_col_ " \
        "LATERAL VIEW explode(data['Confirmed']) confirmed_ AS confirmed_col_ " \
        "LATERAL VIEW explode(data['Recovered']) recovered_ AS recovered_col_ " \
        "LATERAL VIEW explode(data['Deaths']) deaths_ AS deaths_col_) temp_ " \
        "GROUP BY country" % (cnfg_['SOURCE']['database'], cnfg_['SOURCE']['glue-catalog-table'])

cntr_ = sprk_.sql("select * from %s.%s" % (cnfg_['SOURCE']['database'], cnfg_['SOURCE']['glue-catalog-table']))

cntr_aggr_ = cntr_ \
            .select(explode(cntr_['data'])) \
            .select(['col.Country', 'col.Confirmed', 'col.Recovered', 'col.Deaths']) \
            .groupBy('Country') \
            .sum() \
            .withColumnRenamed('Country', 'country') \
            .withColumnRenamed('sum(Confirmed)', 'confirmed') \
            .withColumnRenamed('sum(Recovered)', 'recovered') \
            .withColumnRenamed('sum(Deaths)', 'deaths')

cntr_aggr_.write \
            .mode("overwrite") \
            .format("jdbc") \
            .option("url", "jdbc:mysql://" + cnfg_['TARGET']['host'] + ":" + cnfg_['TARGET']['port'] + "/" + cnfg_['TARGET']['database'] + "?user=" + cnfg_['TARGET']['username'] + "&password=" + cnfg_['TARGET']['password']) \
            .option("dbtable", "covid_country_analysis") \
            .option("driver", "com.mysql.jdbc.Driver") \
            .save()
